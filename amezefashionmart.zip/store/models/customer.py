from django.db import models
class Customer(models.Model):
    name = models.CharField(max_length=50, null=True)
    phone = models.CharField(max_length=15, null=True)
    email = models.EmailField(null=True)
    password = models.CharField(max_length=500, null=True)

    def isExists(self):
        if Customer.objects.filter(email=self.email):
            return True
        return False

    def __str__(self):
        if self.name==None:
            return "NULL"
        return self.name
    @staticmethod
    def get_customer_by_email(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False