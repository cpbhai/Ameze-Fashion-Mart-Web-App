def auth_middleware(get_response):
    #One-time Configuration and initialization
    def middleware(request):
        response = get_response(request)
        return response
    return middleware