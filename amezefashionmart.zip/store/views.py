from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.hashers import make_password, check_password
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
# Create your views here.
def index(request):
    products = None
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = Product.get_all_products_by_cat_id(categoryID)
    else:
        products = Product.get_all_products()
    data = {}
    data['products'] = products
    data['categories'] = categories
    return render(request, 'index.html', data)
def validCustomer(customer):
    error_message = None
    if not customer.name:
        error_message = "Name Required!"
    elif len(customer.phone)<10:
        error_message = "Invalid Phone Number!"
    elif customer.isExists():
        error_message = "Already Registered Email!"
    return error_message
def signup(request):
    if request.method=='POST':
        postdata = request.POST
        name = postdata.get('name')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = make_password(postdata.get('password'))
        #validate
        error_message = None
        customer = Customer(name=name, phone=phone, email=email, password=password)
        error_message = validCustomer(customer)
        if not error_message:
            customer.save()
            return render(request, 'welcome.html')
        return render(request, 'signup.html', {'error':error_message})
    return render(request, 'signup.html')

def login(request):
    if request.method == "GET":
        return render(request, 'login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message=None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                return redirect('http://localhost:8000')
            else:
                error_message="Email or Password Invalid!"
        else:
            error_message="Email or Password Invalid!"
        return render(request, 'login.html', {'error':error_message})